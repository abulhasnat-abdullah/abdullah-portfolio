// Target path: src/components/sections/Experience.jsx
import { motion } from 'framer-motion'
import { experience } from '../../data/portfolio'
import SectionHeading from '../SectionHeading'
import { container, item } from '../../lib/motion'

// Roles within an org card stagger in slightly after the card itself.
const roleList = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.1 } },
}

const roleItem = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] } },
}

export default function Experience({ section }) {
  return (
    <div className="section-page">
      <SectionHeading title={section.title} />
      <motion.div className="org-list" variants={container} initial="hidden" animate="show">
        {experience.map((org) => (
          <motion.article
            key={org.org}
            className="org-card"
            variants={item}
            whileHover={{ y: -4, boxShadow: '0 20px 50px rgba(255, 107, 53, 0.16)' }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          >
            <header className="org-card__header">
              <motion.div
                className="org-card__logo"
                initial={{ opacity: 0, scale: 0.8, rotate: -6 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              >
                <img src={org.logo} alt={`${org.org} logo`} loading="lazy" />
              </motion.div>
              <div>
                <h3>{org.org}</h3>
                <p className="org-card__duration">{org.totalDuration} total</p>
              </div>
            </header>

            <motion.div className="org-card__roles" variants={roleList} initial="hidden" animate="show">
              {org.roles.map((role) => (
                <motion.div key={`${role.title}-${role.period}`} className="org-role" variants={roleItem}>
                  <div className="org-role__head">
                    <div>
                      <h4>{role.title}</h4>
                      <p className="org-role__meta">
                        {[role.type, role.location].filter(Boolean).join(' · ')}
                      </p>
                    </div>
                    <div className="org-role__dates">
                      <time>{role.period}</time>
                      {role.duration && <span>{role.duration}</span>}
                    </div>
                  </div>
                  {role.tags?.length > 0 && (
                    <ul className="tag-list">
                      {role.tags.map((tag) => (
                        <li key={tag}>{tag}</li>
                      ))}
                    </ul>
                  )}
                </motion.div>
              ))}
            </motion.div>
          </motion.article>
        ))}
      </motion.div>
    </div>
  )
}
