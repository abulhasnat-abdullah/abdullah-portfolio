// Target path: src/components/sections/About.jsx
import { motion } from 'framer-motion'
import { profile, researchInterests } from '../../data/portfolio'
import SectionHeading from '../SectionHeading'
import { container, item } from '../../lib/motion'

const photoLinks = [
  { label: 'GitHub', key: 'github' },
  { label: 'LinkedIn', key: 'linkedin' },
  { label: 'Email', key: 'email' },
]

export default function About({ section }) {
  return (
    <div className="section-page">
      <SectionHeading title={section.title} />
      <div className="about about--tab">
        <motion.div
          className="about__hero"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="about__intro">
            <p className="about__kicker">{profile.subtitle}</p>
            <h2 className="about__name">{profile.name}</h2>
            <p className="about__role">
              <span className="about__role-bar" aria-hidden="true" />
              {profile.title}
            </p>
            <p className="about__location">{profile.location}</p>
            <p className="about__tagline">{profile.tagline}</p>
            <p className="about__bio">{profile.bio}</p>

            <ul className="about__credentials">
              {profile.credentials.map((credential) => (
                <li key={credential}>{credential}</li>
              ))}
            </ul>

            <div className="about__cta">
              <a className="about__cta-link" href={profile.links.instagram} target="_blank" rel="noreferrer">
                Art · Instagram
              </a>
              <a className="about__cta-link" href={profile.links.behance} target="_blank" rel="noreferrer">
                Design · Behance
              </a>
            </div>
          </div>

          <div className="about__photo-card">
            <img className="about__photo" src={profile.photo} alt={profile.name} />
            <div className="about__photo-links">
              {photoLinks.map((link) => (
                <a
                  key={link.key}
                  className="about__photo-link"
                  href={profile.links[link.key]}
                  target={link.key === 'email' ? undefined : '_blank'}
                  rel={link.key === 'email' ? undefined : 'noreferrer'}
                >
                  {link.label}
                  <span aria-hidden="true">↗</span>
                </a>
              ))}
            </div>
          </div>
        </motion.div>

        <div className="about__research">
          <h3 className="about__subheading">Research Interests</h3>
          <motion.div className="research-grid" variants={container} initial="hidden" animate="show">
            {researchInterests.map((research) => (
              <motion.article key={research.title} className="research-card" variants={item}>
                <h3>{research.title}</h3>
                <p>{research.description}</p>
                <ul className="tag-list">
                  {research.tags.map((tag) => (
                    <li key={tag}>{tag}</li>
                  ))}
                </ul>
              </motion.article>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  )
}